from fastapi import FastAPI, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional
from datetime import date, datetime
import json
import os
from pathlib import Path

app = FastAPI(title="Personal Finance Manager API")

# Enable CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Data models
class TransactionBase(BaseModel):
    amount: float
    category: str
    description: str
    date: date
    type: str  # 'income' or 'expense'

class TransactionCreate(TransactionBase):
    pass

class Transaction(TransactionBase):
    id: int

    class Config:
        orm_mode = True

# Database setup
DATA_FILE = Path("finance_data.json")

def load_data() -> List[dict]:
    if not DATA_FILE.exists():
        return []
    with open(DATA_FILE, "r") as f:
        return json.load(f)

def save_data(data: List[dict]):
    with open(DATA_FILE, "w") as f:
        json.dump(data, f, default=str)

# API Endpoints
@app.get("/")
async def root():
    return {"message": "Welcome to Personal Finance Manager API"}

@app.get("/transactions", response_model=List[Transaction])
async def get_transactions():
    return load_data()

@app.post("/transactions/", response_model=Transaction)
async def create_transaction(transaction: TransactionCreate):
    data = load_data()
    new_id = max([t.get('id', 0) for t in data] + [0]) + 1
    transaction_data = transaction.dict()
    transaction_data['id'] = new_id
    data.append(transaction_data)
    save_data(data)
    return transaction_data

@app.get("/transactions/summary")
async def get_summary():
    transactions = load_data()
    total_income = sum(t['amount'] for t in transactions if t['type'] == 'income')
    total_expenses = sum(t['amount'] for t in transactions if t['type'] == 'expense')
    savings = total_income - total_expenses
    
    # Group by category
    categories = {}
    for t in transactions:
        if t['type'] == 'expense':  # Only count expenses for category breakdown
            categories[t['category']] = categories.get(t['category'], 0) + t['amount']
    
    return {
        'total_income': total_income,
        'total_expenses': total_expenses,
        'savings': savings,
        'expenses_by_category': categories
    }

# Run the server
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
